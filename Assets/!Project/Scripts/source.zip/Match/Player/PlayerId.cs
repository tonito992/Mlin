﻿namespace com.toni.mlin.Match
{
    public enum PlayerId
    {
        Player1,
        Player2,
        None
    }
}