﻿namespace com.toni.mlin.Match
{
    public enum MatchState
    {
        Placing,
        Moving,
        Flying,
        Removing
    }
}